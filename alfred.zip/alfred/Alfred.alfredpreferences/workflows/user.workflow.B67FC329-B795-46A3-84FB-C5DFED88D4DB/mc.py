import alfredxml
def query(arg):
    
    jsonStr = {
        'black':   { 'base': "#424242", 'dark': "#212121", 'light': "#616161", 'pure': "#000" },
        'gray':    { 'base': "#b0b0b0", 'dark': "#757575", 'light': "#e0e0e0" },
        'white':   { 'base': "#f5f5f5", 'dark': "#eeeeee", 'light': "#fafafa", 'pure': "#fff" },
        'yellow':  { 'base': "#ffd619", 'dark': "#fec517" },
        'gold':    { 'base': "#ffab13", 'dark': "#ff920f" },
        'orange':  { 'base': "#ff6700", 'dark': "#f95b07", 'light': "#ffcc80" },
        'red':     { 'base': "#f23835", 'dark': "#e42a27" },
        'pink':    { 'base': "#f93e7a", 'dark': "#e9306c" },
        'purple':  { 'base': "#a41daf", 'dark': "#9715a2" },
        'indigo':  { 'base': "#545ad1", 'dark': "#494fc5" },
        'blue':    { 'base': "#2096f3", 'dark': "#0c80dc" },
        'cyan':    { 'base': "#00c0a5", 'dark': "#03b3ad" },
        'green':   { 'base': "#83c44e", 'dark': "#71b639" }
    }
    key1 = '' 
    key2 = ''
    for i in jsonStr: 
        colStr = jsonStr[i] 
        for b in colStr:
            val = colStr[b]
            if arg in val: 
                key1 = i
                key2 = b 
    title = ''
    if key2 != 'base':
        title = 'palette(\'' + key1 + '\', \'' + key2 + '\')';
    else:
        title = 'palette(\'' + key1 + '\')';
    rowList = [{
        'uid':'1',
        'arg':title,
        'autocomplete':'',
        'icon':'head_1.png',
        'subtitle':'',
        'title':title
        },{
    	'uid':'2',
    	'arg':'background:'+ title,
    	'autocomplete':'',
    	'icon':'head_1.png',
    	'subtitle':'',
        'title':'background:'+ title
        },{
    	'uid':'3',
    	'arg':'color:'+ title,
    	'autocomplete':'',
    	'icon':'head_1.png',
    	'subtitle':'',
        'title':'color:'+ title
        }]
    element = alfredxml.genAlfredXML(rowList)
    print(element)
    return

# encoding=utf8 
import alfredxml
import urllib
import json
import sys
reload(sys)
sys.setdefaultencoding('utf8')

def query(arg):
    arg = arg.strip()
    rowList = []
    if(len(arg)==0):
        rowList = [{'uid':'1',
                    'arg':'',
                    'autocomplete':'',
                    'icon':'head_1.png',
                    'subtitle':'Please Input',
                    'title':'Please Inputs'}];

        element = alfredxml.genAlfredXML(rowList)
        print(element)
        return
    else: 
        if(arg=='new'):
            rowList = [{'uid':'1',
                    'arg':arg,
                    'autocomplete':'',
                    'icon':'head_1.png',
                    'subtitle':'这么小的字就不要看我了',
                    'title':'Touch me to 新建'}];

        else:
            resp = urllib.urlopen("http://tip.mi.com/article/" + arg)
            rssContent = resp.read()
            decodeRes = json.loads(rssContent, encoding = 'utf-8');
            total = decodeRes['hits']['total'] 
            arr = decodeRes['hits']['hits']
            if(total==0):
                rowList = [{'uid':'1',
                    'arg': arg,
                    'autocomplete':'',
                    'icon':'head_1.png',
                    'subtitle':'nothing',
                    'title':'Sorry'}];
            else:
                for row in arr:     
                    sou = row['_source'] 
                    obj = {
                        'uid': sou['art_id'],
                        'arg': sou['art_id'],
                        'autocomplete':arg,
                        'icon':'head_1.png',
                        'subtitle':'',
                        'title':sou['title'].encode('utf-8')
                    }
                    rowList.append(obj);
               
        element = alfredxml.genAlfredXML(rowList)
        print(element)    


        

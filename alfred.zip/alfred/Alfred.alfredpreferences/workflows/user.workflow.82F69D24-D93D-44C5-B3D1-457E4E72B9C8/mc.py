
def query(arg):